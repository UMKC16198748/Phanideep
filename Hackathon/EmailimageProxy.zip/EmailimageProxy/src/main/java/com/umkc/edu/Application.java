package com.umkc.edu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@SpringBootApplication
public class Application {
    
    @RequestMapping(value="/test")
    public String emailsender(Model model,String resourceName){
        model.addAttribute("image",resourceName);
        return "something";
    }
    
    public static void main(String[] args){
        SpringApplication.run(Application.class, args);
    }
    
}
